import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import dotenv from 'dotenv';
import { AgentManager } from './services/AgentManager.js';
import { DatabaseService } from './services/DatabaseService.js';

dotenv.config();

const app = express();
const server = createServer(app);
const io = new Server(server, {
  cors: {
    origin: ["http://167.71.242.221:5173", "http://167.71.242.221:5174"], // Support both Vite ports
    methods: ["GET", "POST"]
  }
});

app.use(cors());
app.use(express.json());

// Initialize services
const dbService = new DatabaseService();
const agentManager = new AgentManager(dbService);

// AI Discussion State
let aiDiscussionState = {
  isActive: false,
  topic: null,
  startTime: null,
  timeout: 300000, // 5 minutes default
  participants: [],
  messageCount: 0,
  maxMessages: 50,
  canBeInterrupted: true
};

// Initialize database
await dbService.init();
await agentManager.initialize();

// Initialize agent manager
await agentManager.initialize();

// Socket.IO connection handling
io.on('connection', async (socket) => {
  console.log('Client connected:', socket.id);

  // Join the main room
  socket.join('dev-team');

  // Send initial data to the newly connected client
  try {
    // Send agents status
    const agentsStatus = await agentManager.getAgentsStatus();
    socket.emit('agentsUpdate', agentsStatus);

    // Send chat history
    const chatHistory = await dbService.getChatHistory();
    chatHistory.forEach(msg => {
      socket.emit('newMessage', msg);
    });
  } catch (error) {
    console.error('Error sending initial data:', error);
  }

  // Legacy handler - now disabled to prevent duplicates
  // socket.on('human-message', async (data) => { ... });

  // Handle messages (new format for ChatInterface)
  socket.on('message', async (data) => {
    try {
      const { content, sender } = data;
      const messageId = Date.now().toString();
      
      // Store human message
      await dbService.saveMessage({
        id: messageId,
        content,
        sender: sender || 'Client',
        timestamp: new Date().toISOString(),
        type: 'human'
      });

      // Broadcast to all clients
      const newMessage = {
        id: messageId,
        content,
        sender: sender || 'Client',
        timestamp: new Date().toISOString(),
        type: 'human'
      };
      
      io.to('dev-team').emit('newMessage', newMessage);

      // Trigger AI responses
      agentManager.processHumanMessage(content, (aiResponse) => {
        io.to('dev-team').emit('newMessage', aiResponse);
      });

    } catch (error) {
      console.error('Error handling message:', error);
      socket.emit('error', { message: 'Failed to process message' });
    }
  });

  // Handle agent control
  socket.on('toggle-agent', async (data) => {
    try {
      const { agentId, active } = data;
      await agentManager.toggleAgent(agentId, active);
      
      // Broadcast agent status update
      io.to('dev-team').emit('agent-status-update', {
        agentId,
        active,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error toggling agent:', error);
      socket.emit('error', { message: 'Failed to toggle agent' });
    }
  });

  // Handle role change
  socket.on('change-agent-role', async (data) => {
    try {
      const { agentId, newRole } = data;
      await agentManager.changeAgentRole(agentId, newRole);
      
      // Broadcast role change
      io.to('dev-team').emit('agent-role-change', {
        agentId,
        newRole,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error changing agent role:', error);
      socket.emit('error', { message: 'Failed to change agent role' });
    }
  });

  // Send chat history on connection
  socket.on('request-chat-history', async () => {
    try {
      const history = await dbService.getChatHistory();
      socket.emit('chat-history', history);
    } catch (error) {
      console.error('Error fetching chat history:', error);
      socket.emit('error', { message: 'Failed to fetch chat history' });
    }
  });

  // Start endless AI discussion
  socket.on('start-ai-discussion', async (data) => {
    try {
      const { topic, timeout = 300000, maxMessages = 50 } = data;
      
      if (aiDiscussionState.isActive) {
        socket.emit('error', { message: 'AI discussion already in progress' });
        return;
      }

      aiDiscussionState = {
        isActive: true,
        topic,
        startTime: new Date(),
        timeout,
        participants: ['PO', 'SENIOR', 'JUNIOR'],
        messageCount: 0,
        maxMessages,
        canBeInterrupted: true
      };

      // Broadcast discussion start
      io.to('dev-team').emit('ai-discussion-started', {
        topic,
        timeout,
        maxMessages,
        startTime: aiDiscussionState.startTime
      });

      // Start the AI discussion loop
      startAIDiscussion(topic);

    } catch (error) {
      console.error('Error starting AI discussion:', error);
      socket.emit('error', { message: 'Failed to start AI discussion' });
    }
  });

  // CEO/Human override to stop AI discussion
  socket.on('ceo-override', async (data) => {
    try {
      const { reason, finalReport } = data;
      
      if (!aiDiscussionState.isActive) {
        socket.emit('error', { message: 'No AI discussion in progress to override' });
        return;
      }

      // Stop the AI discussion
      aiDiscussionState.isActive = false;
      aiDiscussionState.canBeInterrupted = false;

      // Send CEO override message
      const overrideMessage = {
        id: Date.now(),
        content: `🛑 **CEO OVERRIDE**: AI discussion stopped. ${reason ? `Reason: ${reason}` : ''}`,
        sender: 'CEO',
        timestamp: new Date().toISOString(),
        isSystemMessage: true
      };

      await dbService.saveMessage(overrideMessage);
      io.to('dev-team').emit('newMessage', overrideMessage);

      // If final report requested, ask PO to generate it
      if (finalReport) {
        const reportRequest = {
          id: Date.now() + 1,
          content: `@PO Please generate a comprehensive report of our discussion on "${aiDiscussionState.topic}" and tag @CEO and @HUMAN with the final results.`,
          sender: 'System',
          timestamp: new Date().toISOString(),
          isSystemMessage: true
        };

        await dbService.saveMessage(reportRequest);
        io.to('dev-team').emit('newMessage', reportRequest);

        // Trigger PO to respond
        setTimeout(() => {
          triggerAgentResponse('PO', reportRequest.content);
        }, 2000);
      }

      // Reset discussion state
      aiDiscussionState = {
        isActive: false,
        topic: null,
        startTime: null,
        timeout: 300000,
        participants: [],
        messageCount: 0,
        maxMessages: 50,
        canBeInterrupted: true
      };

      // Broadcast discussion ended
      io.to('dev-team').emit('ai-discussion-ended', { reason, finalReport });

    } catch (error) {
      console.error('Error handling CEO override:', error);
      socket.emit('error', { message: 'Failed to process CEO override' });
    }
  });

  // Get AI discussion status
  socket.on('get-discussion-status', () => {
    socket.emit('discussion-status', aiDiscussionState);
  });

  // Send agent status on connection
  socket.on('request-agent-status', async () => {
    try {
      const status = await agentManager.getAgentsStatus();
      socket.emit('agents-status', status);
    } catch (error) {
      console.error('Error fetching agent status:', error);
      socket.emit('error', { message: 'Failed to fetch agent status' });
    }
  });

  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
  });
});

// REST API endpoints
app.get('/api/health', (req, res) => {
  res.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

app.get('/api/agents/status', async (req, res) => {
  try {
    const status = await agentManager.getAgentsStatus();
    res.json(status);
  } catch (error) {
    console.error('Error getting agents status:', error);
    res.status(500).json({ error: 'Failed to get agents status' });
  }
});

app.get('/api/chat/history', async (req, res) => {
  try {
    const history = await dbService.getChatHistory();
    res.json(history);
  } catch (error) {
    console.error('Error getting chat history:', error);
    res.status(500).json({ error: 'Failed to get chat history' });
  }
});

const PORT = process.env.PORT || 3001;

// AI Discussion Functions
async function startAIDiscussion(topic) {
  console.log(`<i class="bi bi-robot"></i> Starting AI discussion on: ${topic}`);
  
  // Initial PO message to kick off discussion
  const initialMessage = {
    id: Date.now(),
    content: `Let's discuss: ${topic}. I'd like everyone to share their thoughts and we'll work through this systematically.`,
    sender: 'PO',
    timestamp: new Date().toISOString()
  };

  await dbService.saveMessage(initialMessage);
  io.to('dev-team').emit('newMessage', initialMessage);
  aiDiscussionState.messageCount++;

  // Start the discussion loop
  setTimeout(() => continueAIDiscussion(), 5000);
}

async function continueAIDiscussion() {
  if (!aiDiscussionState.isActive || !aiDiscussionState.canBeInterrupted) {
    return;
  }

  // Check timeout
  const now = new Date();
  const elapsed = now - aiDiscussionState.startTime;
  if (elapsed > aiDiscussionState.timeout) {
    await endAIDiscussion('timeout');
    return;
  }

  // Check message limit
  if (aiDiscussionState.messageCount >= aiDiscussionState.maxMessages) {
    await endAIDiscussion('message_limit');
    return;
  }

  // Pick random participant to respond
  const participants = aiDiscussionState.participants;
  const randomAgent = participants[Math.floor(Math.random() * participants.length)];
  
  // Generate contextual response
  const discussionPrompts = [
    `I think we should consider the scalability aspects of ${aiDiscussionState.topic}`,
    `From a technical perspective, ${aiDiscussionState.topic} requires careful planning`,
    `Let me add some insights about ${aiDiscussionState.topic} from my experience`,
    `We need to think about potential challenges with ${aiDiscussionState.topic}`,
    `I'd like to propose an alternative approach to ${aiDiscussionState.topic}`,
    `The implementation details for ${aiDiscussionState.topic} are crucial`,
    `Let's consider the user experience implications of ${aiDiscussionState.topic}`,
    `Security considerations for ${aiDiscussionState.topic} are important`
  ];

  const randomPrompt = discussionPrompts[Math.floor(Math.random() * discussionPrompts.length)];
  
  // Trigger agent response
  await triggerAgentResponse(randomAgent, randomPrompt);
  aiDiscussionState.messageCount++;

  // Continue the discussion
  const delay = Math.random() * 10000 + 5000; // 5-15 seconds
  setTimeout(() => continueAIDiscussion(), delay);
}

async function triggerAgentResponse(agentId, prompt) {
  try {
    const response = await agentManager.processMessage({
      content: prompt,
      sender: 'System',
      targetAgent: agentId
    });

    if (response) {
      const agentMessage = {
        id: Date.now(),
        content: response,
        sender: agentId,
        timestamp: new Date().toISOString()
      };

      await dbService.saveMessage(agentMessage);
      io.to('dev-team').emit('newMessage', agentMessage);
    }
  } catch (error) {
    console.error(`Error getting response from ${agentId}:`, error);
  }
}

async function endAIDiscussion(reason) {
  aiDiscussionState.isActive = false;
  
  let endMessage = '';
  switch (reason) {
    case 'timeout':
      endMessage = '⏰ AI discussion ended due to timeout';
      break;
    case 'message_limit':
      endMessage = '📝 AI discussion ended due to message limit reached';
      break;
    default:
      endMessage = '✅ AI discussion ended';
  }

  const endMsg = {
    id: Date.now(),
    content: endMessage,
    sender: 'System',
    timestamp: new Date().toISOString(),
    isSystemMessage: true
  };

  await dbService.saveMessage(endMsg);
  io.to('dev-team').emit('newMessage', endMsg);
  io.to('dev-team').emit('ai-discussion-ended', { reason });

  // Ask PO to generate final report
  const reportRequest = {
    id: Date.now() + 1,
    content: `@PO Please summarize our discussion on "${aiDiscussionState.topic}" and tag @CEO and @HUMAN with the key outcomes.`,
    sender: 'System',
    timestamp: new Date().toISOString(),
    isSystemMessage: true
  };

  await dbService.saveMessage(reportRequest);
  io.to('dev-team').emit('newMessage', reportRequest);

  setTimeout(() => {
    triggerAgentResponse('PO', reportRequest.content);
  }, 3000);
}

server.listen(PORT, () => {
  console.log(`🚀 Server running on http://167.71.242.221:${PORT}`);
  console.log(`📡 Socket.IO server ready`);
});
