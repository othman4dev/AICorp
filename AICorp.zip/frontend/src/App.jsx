import React, { useState, useEffect } from 'react';
import './styles/ModernTheme.css';
import ChatInterface from './components/ChatInterface';
import AgentControl from './components/AgentControl';
import AIDiscussion from './components/AIDiscussion';
import socketService from './services/socketService';

function App() {
  const [activeTab, setActiveTab] = useState('team');
  const [agents, setAgents] = useState([]);
  const [connectionStatus, setConnectionStatus] = useState('disconnected');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const initializeApp = async () => {
      try {
        await socketService.connect();
        
        socketService.on('agents_updated', (agentsData) => {
          setAgents(agentsData);
          setIsLoading(false);
        });

        socketService.on('connect', () => {
          setConnectionStatus('connected');
          setIsLoading(false);
        });

        socketService.on('disconnect', () => {
          setConnectionStatus('disconnected');
        });

        // Set a fallback timeout
        setTimeout(() => {
          setIsLoading(false);
        }, 3000);

      } catch (error) {
        console.error('Failed to initialize app:', error);
        setIsLoading(false);
      }
    };

    initializeApp();

    return () => {
      socketService.disconnect();
    };
  }, []);

  const renderTabContent = () => {
    switch (activeTab) {
      case 'team':
        return <ChatInterface agents={agents} connectionStatus={connectionStatus} />;
      case 'control':
        return <AgentControl agents={agents} connectionStatus={connectionStatus} />;
      case 'discussion':
        return <AIDiscussion connectionStatus={connectionStatus} />;
      default:
        return <ChatInterface agents={agents} connectionStatus={connectionStatus} />;
    }
  };

  if (isLoading) {
    return (
      <div className="loading">
        <div className="loading-content">
          <div className="spinner"></div>
          <h3>Initializing AI Team</h3>
          <p>Setting up your development agents...</p>
          <div className="loading-actions">
            <button 
              className="btn" 
              onClick={() => setIsLoading(false)}
            >
              Skip
            </button>
            <button 
              className="btn secondary" 
              onClick={() => window.location.reload()}
            >
              Reload
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="app">
      <header className="header">
        <div className="brand">
          <div className="brand-icon"><i class="bi bi-robot"></i></div>
          <div className="brand-text">
            <h1>AICorp Dev Team</h1>
            <p>Multi-Agent Development Simulator</p>
          </div>
        </div>
        <div className="version">v2.0.0</div>
      </header>

      <div className="app-body">
        <div className="sidebar">
          <div className="tabs">
            <button 
              className={`tab ${activeTab === 'team' ? 'active' : ''}`}
              onClick={() => setActiveTab('team')}
            >
              Team Chat
            </button>
            <button 
              className={`tab ${activeTab === 'control' ? 'active' : ''}`}
              onClick={() => setActiveTab('control')}
            >
              Agent Control
            </button>
            <button 
              className={`tab ${activeTab === 'discussion' ? 'active' : ''}`}
              onClick={() => setActiveTab('discussion')}
            >
              AI Discussion
            </button>
          </div>

          <div className="tab-content">
            <div className="welcome">
              <div className="welcome-card">
                <h3><i class="bi bi-postage-heart"></i> Welcome!</h3>
                <p>
                  Chat with your AI development team. They'll collaborate to help 
                  you build features, review code, and manage tasks.
                </p>
              </div>

              <div className="welcome-card">
                <h3><i class="bi bi-rocket-takeoff-fill"></i> Try these commands:</h3>
                <div className="command-list">
                  <div className="command-item">"Build a simple calculator component"</div>
                  <div className="command-item">"@PO Create a user authentication system"</div>
                  <div className="command-item">"@SENIOR Review my React component code"</div>
                  <div className="command-item">"@JUNIOR Implement a shopping cart feature"</div>
                </div>
              </div>

              <div className="welcome-card">
                <h3><i class="bi bi-tag-fill"></i> Agent Tagging System</h3>
                <p style={{ marginBottom: '12px' }}>Tag specific agents to get focused responses:</p>
                <div className="tag-grid">
                  <div className="tag-item">
                    <span>@PO</span>
                    <span>→ Product Owner</span>
                  </div>
                  <div className="tag-item">
                    <span>@SENIOR</span>
                    <span>→ Senior Developer</span>
                  </div>
                  <div className="tag-item">
                    <span>@JUNIOR</span>
                    <span>→ Junior Developer</span>
                  </div>
                  <div className="tag-item">
                    <span>@ALL</span>
                    <span>→ Everyone</span>
                  </div>
                  <div className="tag-item">
                    <span>@CEO</span>
                    <span>→ CEO Override</span>
                  </div>
                  <div className="tag-item">
                    <span>@HUMAN</span>
                    <span>→ Human Input</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <main className="main">
          {renderTabContent()}
        </main>
      </div>
    </div>
  );
}

export default App;
