import React, { useState, useEffect, useRef } from 'react';
import socketService from '../services/socketService';

const AIDiscussion = ({ connectionStatus = 'disconnected' }) => {
  const [isDiscussionActive, setIsDiscussionActive] = useState(false);
  const [discussionMessages, setDiscussionMessages] = useState([]);
  const [discussionConfig, setDiscussionConfig] = useState({
    topic: '',
    timeout: 300, // 5 minutes
    maxMessages: 50,
    autoStop: true,
    enableCEO: true
  });
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [messageCount, setMessageCount] = useState(0);
  const messagesEndRef = useRef(null);
  const timerRef = useRef(null);

  useEffect(() => {
    // Listen for AI discussion events
    const handleDiscussionMessage = (messageData) => {
      const message = {
        id: Date.now() + Math.random(),
        sender: messageData.sender || messageData.agent || 'AI',
        content: messageData.message || messageData.content || '',
        timestamp: new Date().toISOString(),
        type: messageData.type || 'discussion'
      };
      
      setDiscussionMessages(prev => [...prev, message]);
      setMessageCount(prev => prev + 1);
    };

    const handleDiscussionStart = () => {
      setIsDiscussionActive(true);
      setTimeRemaining(discussionConfig.timeout);
      startTimer();
    };

    const handleDiscussionEnd = () => {
      setIsDiscussionActive(false);
      setTimeRemaining(0);
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };

    socketService.on('ai_discussion_message', handleDiscussionMessage);
    socketService.on('discussion_started', handleDiscussionStart);
    socketService.on('discussion_ended', handleDiscussionEnd);
    
    return () => {
      socketService.off('ai_discussion_message', handleDiscussionMessage);
      socketService.off('discussion_started', handleDiscussionStart);
      socketService.off('discussion_ended', handleDiscussionEnd);
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [discussionConfig.timeout]);

  useEffect(() => {
    scrollToBottom();
  }, [discussionMessages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const startTimer = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    
    timerRef.current = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          setIsDiscussionActive(false);
          clearInterval(timerRef.current);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const startDiscussion = () => {
    if (!discussionConfig.topic.trim()) {
      alert('Please enter a discussion topic');
      return;
    }

    setDiscussionMessages([]);
    setMessageCount(0);
    setIsDiscussionActive(true);
    setTimeRemaining(discussionConfig.timeout);
    
    socketService.emit('start_ai_discussion', {
      topic: discussionConfig.topic,
      config: discussionConfig
    });
    
    startTimer();
  };

  const stopDiscussion = () => {
    setIsDiscussionActive(false);
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    
    socketService.emit('stop_ai_discussion');
  };

  const emergencyStop = () => {
    stopDiscussion();
    socketService.emit('emergency_stop');
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getProgressPercentage = () => {
    return ((discussionConfig.timeout - timeRemaining) / discussionConfig.timeout) * 100;
  };

  const formatContent = (content) => {
    if (!content) return '';
    
    let formattedContent = content;
    
    // Format mentions
    formattedContent = formattedContent.replace(/@(\w+)/g, '<span class="mention">@$1</span>');
    
    // Format code blocks
    formattedContent = formattedContent.replace(/```([^`]+)```/g, '<div class="code-block"><pre>$1</pre></div>');
    formattedContent = formattedContent.replace(/`([^`]+)`/g, '<span class="inline-code">$1</span>');
    
    return formattedContent;
  };

  const getAgentInfo = (sender) => {
    const agentMap = {
      'Junior Developer': { emoji: '👨‍💻', name: 'Junior Dev', color: 'junior' },
      'Senior Developer': { emoji: '👩‍💻', name: 'Senior Dev', color: 'senior' },
      'Scrum Master/PO': { emoji: '👔', name: 'Product Owner', color: 'po' },
      'CEO': { emoji: '💼', name: 'CEO', color: 'ceo' },
      'AI': { emoji: '<i class="bi bi-robot"></i>', name: 'AI Assistant', color: 'agent' }
    };
    
    return agentMap[sender] || { emoji: '<i class="bi bi-robot"></i>', name: sender, color: 'agent' };
  };

  return (
    <>
      {/* Header */}
      <div className="discussion-header">
        <div className="header-info">
          <h2 className="discussion-title"><i class="bi bi-cpu-fill"></i> AI Discussion Lab</h2>
          <div className="discussion-status">
            <div className={`status-dot ${isDiscussionActive ? 'active' : 'inactive'}`}></div>
            <span className="status-text">
              {isDiscussionActive ? 'Discussion Active' : 'Ready to Start'}
            </span>
          </div>
        </div>
        
        {isDiscussionActive && (
          <div className="discussion-controls">
            <div className="timer-display">
              <span className="timer-icon">⏱️</span>
              <span className="timer-text">{formatTime(timeRemaining)}</span>
            </div>
            <div className="message-counter">
              <span className="counter-text">{messageCount}/{discussionConfig.maxMessages}</span>
            </div>
          </div>
        )}
      </div>

      {/* Configuration Panel */}
      {!isDiscussionActive && (
        <div className="setup-panel">
          <div className="setup-section">
            <h3 className="section-title"><i class="bi bi-bullseye"></i> Discussion Setup</h3>
            
            <div className="form-group">
              <label className="form-label">Discussion Topic</label>
              <textarea
                className="topic-input"
                value={discussionConfig.topic}
                onChange={(e) => setDiscussionConfig(prev => ({ ...prev, topic: e.target.value }))}
                placeholder="Enter a topic for AI agents to discuss... e.g., 'Design a new authentication system' or 'Review best practices for React components'"
                rows={3}
              />
            </div>
            
            <div className="config-row">
              <div className="form-group">
                <label className="form-label">Timeout (minutes)</label>
                <input
                  type="number"
                  min="1"
                  max="60"
                  value={discussionConfig.timeout / 60}
                  onChange={(e) => setDiscussionConfig(prev => ({ 
                    ...prev, 
                    timeout: parseInt(e.target.value) * 60 
                  }))}
                  className="number-input"
                />
              </div>
              
              <div className="form-group">
                <label className="form-label">Max Messages</label>
                <input
                  type="number"
                  min="10"
                  max="200"
                  value={discussionConfig.maxMessages}
                  onChange={(e) => setDiscussionConfig(prev => ({ 
                    ...prev, 
                    maxMessages: parseInt(e.target.value) 
                  }))}
                  className="number-input"
                />
              </div>
            </div>
            
            <div className="checkbox-group">
              <label className="checkbox-item">
                <input
                  type="checkbox"
                  checked={discussionConfig.autoStop}
                  onChange={(e) => setDiscussionConfig(prev => ({ 
                    ...prev, 
                    autoStop: e.target.checked 
                  }))}
                />
                <span className="checkbox-text">Auto-stop when timeout reached</span>
              </label>
              
              <label className="checkbox-item">
                <input
                  type="checkbox"
                  checked={discussionConfig.enableCEO}
                  onChange={(e) => setDiscussionConfig(prev => ({ 
                    ...prev, 
                    enableCEO: e.target.checked 
                  }))}
                />
                <span className="checkbox-text">Enable CEO override capabilities</span>
              </label>
            </div>
            
            <div className="setup-actions">
              <button 
                className="start-btn"
                onClick={startDiscussion}
                disabled={!discussionConfig.topic.trim() || connectionStatus !== 'connected'}
              >
                <span className="btn-icon"><i class="bi bi-rocket-takeoff-fill"></i></span>
                <span className="btn-text">Start AI Discussion</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Active Discussion Controls */}
      {isDiscussionActive && (
        <div className="active-controls">
          <div className="progress-section">
            <div className="progress-info">
              <span className="progress-label">Discussion Progress</span>
              <span className="progress-stats">
                {messageCount}/{discussionConfig.maxMessages} messages • {formatTime(timeRemaining)} remaining
              </span>
            </div>
            <div className="progress-bar">
              <div 
                className="progress-fill" 
                style={{ width: `${getProgressPercentage()}%` }}
              ></div>
            </div>
          </div>
          
          <div className="control-actions">
            <button className="control-btn pause" onClick={stopDiscussion}>
              <span>⏸️</span> Pause Discussion
            </button>
            <button className="control-btn emergency" onClick={emergencyStop}>
              <span>🛑</span> Emergency Stop
            </button>
            <button className="control-btn ceo" onClick={() => socketService.emit('ceo_override')}>
              <span>💼</span> CEO Override
            </button>
          </div>
        </div>
      )}

      {/* Discussion Messages */}
      <div className="discussion-container">
        <div className="discussion-messages">
          {discussionMessages.length === 0 ? (
            <div className="discussion-empty">
              <div className="empty-content">
                <div className="empty-icon"><i class="bi bi-cpu-fill"></i></div>
                <h3 className="empty-title">
                  {isDiscussionActive ? 'AI Discussion Starting...' : 'Ready for AI Discussion'}
                </h3>
                <p className="empty-subtitle">
                  {isDiscussionActive 
                    ? 'Your AI agents are preparing to discuss the topic...' 
                    : 'Set up a topic above and start an autonomous AI discussion between your development team.'
                  }
                </p>
              </div>
            </div>
          ) : (
            <>
              {discussionMessages.map((message) => {
                const agentInfo = getAgentInfo(message.sender);
                return (
                  <div key={message.id} className={`discussion-message ${agentInfo.color}`}>
                    <div className="message-avatar">
                      <div className={`avatar ${agentInfo.color}`}>
                        {agentInfo.emoji}
                      </div>
                    </div>
                    <div className="message-content">
                      <div className="message-header">
                        <span className="sender-name">{agentInfo.name}</span>
                        <span className="message-time">
                          {new Date(message.timestamp).toLocaleTimeString([], { 
                            hour: '2-digit', 
                            minute: '2-digit',
                            second: '2-digit'
                          })}
                        </span>
                      </div>
                      <div 
                        className="message-text" 
                        dangerouslySetInnerHTML={{ 
                          __html: formatContent(message.content) 
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>
    </>
  );
};

export default AIDiscussion;
