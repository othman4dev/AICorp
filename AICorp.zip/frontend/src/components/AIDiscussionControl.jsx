import React, { useState, useEffect } from 'react';
import { socketService } from '../services/socketService';
import '../styles/FuturisticTheme.css';

const AIDiscussionControl = () => {
  const [discussionState, setDiscussionState] = useState({
    isActive: false,
    topic: null,
    startTime: null,
    messageCount: 0,
    maxMessages: 50,
    timeout: 300000
  });
  
  const [controlForm, setControlForm] = useState({
    topic: '',
    timeout: 5, // minutes
    maxMessages: 50,
    overrideReason: '',
    generateReport: true
  });

  const [showCEOControls, setShowCEOControls] = useState(false);

  useEffect(() => {
    const socket = socketService.getSocket();
    if (!socket) return;

    const handleDiscussionStarted = (data) => {
      setDiscussionState({
        isActive: true,
        topic: data.topic,
        startTime: data.startTime,
        messageCount: 0,
        maxMessages: data.maxMessages,
        timeout: data.timeout
      });
    };

    const handleDiscussionEnded = (data) => {
      setDiscussionState(prev => ({
        ...prev,
        isActive: false,
        topic: null,
        startTime: null
      }));
    };

    const handleDiscussionStatus = (status) => {
      setDiscussionState(status);
    };

    socket.on('ai-discussion-started', handleDiscussionStarted);
    socket.on('ai-discussion-ended', handleDiscussionEnded);
    socket.on('discussion-status', handleDiscussionStatus);

    // Request current status
    socket.emit('get-discussion-status');

    return () => {
      socket.off('ai-discussion-started', handleDiscussionStarted);
      socket.off('ai-discussion-ended', handleDiscussionEnded);
      socket.off('discussion-status', handleDiscussionStatus);
    };
  }, []);

  const startAIDiscussion = () => {
    if (!controlForm.topic.trim()) {
      alert('Please enter a discussion topic');
      return;
    }

    const socket = socketService.getSocket();
    socket.emit('start-ai-discussion', {
      topic: controlForm.topic,
      timeout: controlForm.timeout * 60 * 1000, // convert minutes to milliseconds
      maxMessages: controlForm.maxMessages
    });

    // Reset form
    setControlForm(prev => ({ ...prev, topic: '' }));
  };

  const ceoOverride = () => {
    const socket = socketService.getSocket();
    socket.emit('ceo-override', {
      reason: controlForm.overrideReason,
      finalReport: controlForm.generateReport
    });

    // Reset override form
    setControlForm(prev => ({ 
      ...prev, 
      overrideReason: '',
      generateReport: true 
    }));
    setShowCEOControls(false);
  };

  const getRemainingTime = () => {
    if (!discussionState.isActive || !discussionState.startTime) return 0;
    
    const elapsed = Date.now() - new Date(discussionState.startTime).getTime();
    const remaining = Math.max(0, discussionState.timeout - elapsed);
    return Math.ceil(remaining / 1000 / 60); // minutes
  };

  const getProgress = () => {
    if (!discussionState.isActive) return 0;
    return (discussionState.messageCount / discussionState.maxMessages) * 100;
  };

  return (
    <div className="ai-discussion-control">
      <div className="control-header">
        <h3 className="text-lg font-semibold text-white mb-2"><i class="bi bi-robot"></i> AI Discussion Control</h3>
        {discussionState.isActive && (
          <div className="discussion-status">
            <div className="status-indicator active">
              <span className="pulse-dot"></span>
              Discussion Active
            </div>
            <div className="status-details">
              <p className="text-sm text-blue-300">Topic: {discussionState.topic}</p>
              <p className="text-sm text-gray-300">
                Time remaining: ~{getRemainingTime()} minutes | 
                Messages: {discussionState.messageCount}/{discussionState.maxMessages}
              </p>
              <div className="progress-bar">
                <div 
                  className="progress-fill" 
                  style={{ width: `${getProgress()}%` }}
                ></div>
              </div>
            </div>
          </div>
        )}
      </div>

      {!discussionState.isActive ? (
        <div className="start-discussion-form">
          <div className="form-group">
            <label className="form-label">Discussion Topic</label>
            <input
              type="text"
              value={controlForm.topic}
              onChange={(e) => setControlForm(prev => ({ ...prev, topic: e.target.value }))}
              placeholder="e.g., Implementing user authentication system"
              className="futuristic-input"
            />
          </div>
          
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Timeout (minutes)</label>
              <input
                type="number"
                value={controlForm.timeout}
                onChange={(e) => setControlForm(prev => ({ ...prev, timeout: parseInt(e.target.value) || 5 }))}
                min="1"
                max="60"
                className="futuristic-input"
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Max Messages</label>
              <input
                type="number"
                value={controlForm.maxMessages}
                onChange={(e) => setControlForm(prev => ({ ...prev, maxMessages: parseInt(e.target.value) || 50 }))}
                min="10"
                max="200"
                className="futuristic-input"
              />
            </div>
          </div>

          <button
            onClick={startAIDiscussion}
            className="futuristic-btn futuristic-btn-blue w-full"
          >
            <i class="bi bi-rocket-takeoff-fill"></i> Start AI Discussion
          </button>
        </div>
      ) : (
        <div className="active-discussion-controls">
          <div className="ceo-controls">
            {!showCEOControls ? (
              <button
                onClick={() => setShowCEOControls(true)}
                className="futuristic-btn futuristic-btn-gold"
              >
                👑 CEO Override
              </button>
            ) : (
              <div className="override-form">
                <div className="form-group">
                  <label className="form-label">Override Reason (Optional)</label>
                  <input
                    type="text"
                    value={controlForm.overrideReason}
                    onChange={(e) => setControlForm(prev => ({ ...prev, overrideReason: e.target.value }))}
                    placeholder="e.g., Need to shift focus to urgent issue"
                    className="futuristic-input"
                  />
                </div>
                
                <div className="checkbox-group">
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={controlForm.generateReport}
                      onChange={(e) => setControlForm(prev => ({ ...prev, generateReport: e.target.checked }))}
                      className="futuristic-checkbox"
                    />
                    Generate final report with @CEO @HUMAN tags
                  </label>
                </div>

                <div className="button-row">
                  <button
                    onClick={ceoOverride}
                    className="futuristic-btn futuristic-btn-red"
                  >
                    🛑 Stop Discussion
                  </button>
                  <button
                    onClick={() => setShowCEOControls(false)}
                    className="futuristic-btn futuristic-btn-gray"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      <div className="help-text">
        <p className="text-xs text-gray-400">
          💡 AI agents will discuss the topic endlessly until timeout, message limit, or CEO override.
        </p>
      </div>
    </div>
  );
};

export default AIDiscussionControl;
