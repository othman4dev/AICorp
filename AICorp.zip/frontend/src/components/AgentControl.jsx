import React, { useState, useEffect } from 'react';
import socketService from '../services/socketService';

const AgentControl = ({ agents = [], connectionStatus = 'disconnected' }) => {
  const [controlState, setControlState] = useState({
    autoMode: true,
    responseDelay: 1000,
    maxMessagesPerAgent: 5,
    discussionTimeout: 300000, // 5 minutes
  });

  const [agentStats, setAgentStats] = useState({});
  const [isConfiguring, setIsConfiguring] = useState(false);

  useEffect(() => {
    // Listen for agent statistics
    socketService.on('agent_stats', (stats) => {
      setAgentStats(stats);
    });

    return () => {
      socketService.off('agent_stats');
    };
  }, []);

  const handleConfigChange = (key, value) => {
    const newState = { ...controlState, [key]: value };
    setControlState(newState);
    
    // Send configuration to backend
    socketService.emit('update_config', newState);
  };

  const resetAgentState = (agentId) => {
    socketService.emit('reset_agent', { agentId });
  };

  const pauseAgent = (agentId) => {
    socketService.emit('pause_agent', { agentId });
  };

  const resumeAgent = (agentId) => {
    socketService.emit('resume_agent', { agentId });
  };

  const getAgentInfo = (agent) => {
    const agentTypes = {
      'Junior Developer': { 
        icon: '👨‍💻', 
        color: 'junior',
        description: 'Handles basic tasks, learns from seniors'
      },
      'Senior Developer': { 
        icon: '👩‍💻', 
        color: 'senior',
        description: 'Reviews code, architects solutions'
      },
      'Scrum Master/PO': { 
        icon: '👔', 
        color: 'po',
        description: 'Manages tasks, defines requirements'
      },
      'CEO': { 
        icon: '💼', 
        color: 'ceo',
        description: 'Final decisions, strategic oversight'
      }
    };

    return agentTypes[agent] || { 
      icon: '<i class="bi bi-robot"></i>', 
      color: 'default',
      description: 'AI Assistant'
    };
  };

  return (
    <>
      {/* Header */}
      <div className="control-header">
        <div className="header-info">
          <h2 className="control-title"><i class="bi bi-ui-radios-grid"></i> Agent Control Center</h2>
          <p className="control-subtitle">
            Manage your AI development team settings and behavior
          </p>
        </div>
        <div className="header-actions">
          <button 
            className={`toggle-btn ${controlState.autoMode ? 'active' : ''}`}
            onClick={() => handleConfigChange('autoMode', !controlState.autoMode)}
          >
            <span className="toggle-icon"><i class="bi bi-robot"></i></span>
            <span className="toggle-text">Auto Mode</span>
          </button>
        </div>
      </div>

      {/* Configuration Panel */}
      <div className="config-panel">
        <div className="config-section">
          <h3 className="section-title"><i class="bi bi-gear"></i> System Configuration</h3>
          
          <div className="config-grid">
            <div className="config-item">
              <label className="config-label">Response Delay (ms)</label>
              <div className="input-group">
                <input
                  type="range"
                  min="500"
                  max="5000"
                  step="100"
                  value={controlState.responseDelay}
                  onChange={(e) => handleConfigChange('responseDelay', parseInt(e.target.value))}
                  className="range-input"
                />
                <span className="config-value">{controlState.responseDelay}ms</span>
              </div>
            </div>

            <div className="config-item">
              <label className="config-label">Max Messages Per Agent</label>
              <div className="input-group">
                <input
                  type="range"
                  min="1"
                  max="20"
                  value={controlState.maxMessagesPerAgent}
                  onChange={(e) => handleConfigChange('maxMessagesPerAgent', parseInt(e.target.value))}
                  className="range-input"
                />
                <span className="config-value">{controlState.maxMessagesPerAgent}</span>
              </div>
            </div>

            <div className="config-item">
              <label className="config-label">Discussion Timeout (minutes)</label>
              <div className="input-group">
                <input
                  type="range"
                  min="1"
                  max="30"
                  value={controlState.discussionTimeout / 60000}
                  onChange={(e) => handleConfigChange('discussionTimeout', e.target.value * 60000)}
                  className="range-input"
                />
                <span className="config-value">{controlState.discussionTimeout / 60000}min</span>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="config-section">
          <h3 className="section-title"><i class="bi bi-lightning-charge-fill"></i> Quick Actions</h3>
          <div className="action-grid">
            <button className="action-card" onClick={() => socketService.emit('reset_all_agents')}>
              <div className="action-icon"><i class="bi bi-repeat"></i></div>
              <div className="action-text">
                <h4>Reset All Agents</h4>
                <p>Clear all agent memory and state</p>
              </div>
            </button>
            
            <button className="action-card" onClick={() => socketService.emit('pause_discussion')}>
              <div className="action-icon"><i class="bi bi-pause-fill"></i></div>
              <div className="action-text">
                <h4>Pause Discussion</h4>
                <p>Stop all automatic responses</p>
              </div>
            </button>
            
            <button className="action-card" onClick={() => socketService.emit('emergency_stop')}>
              <div className="action-icon"><i class="bi bi-stop-fill"></i></div>
              <div className="action-text">
                <h4>Emergency Stop</h4>
                <p>Immediately halt all agents</p>
              </div>
            </button>
            
            <button className="action-card" onClick={() => socketService.emit('save_session')}>
              <div className="action-icon"><i class="bi bi-floppy2-fill"></i></div>
              <div className="action-text">
                <h4>Save Session</h4>
                <p>Export conversation history</p>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Agent Status */}
      <div className="agents-panel">
        <h3 className="section-title">👥 Agent Status</h3>
        
        {agents.length === 0 ? (
          <div className="empty-agents">
            <div className="empty-icon"><i class="bi bi-robot"></i></div>
            <h4>No agents connected</h4>
            <p>Waiting for AI agents to come online...</p>
            <button className="connect-btn" onClick={() => socketService.emit('request_agents')}>
              <span><i class="bi bi-repeat"></i></span> Refresh Agents
            </button>
          </div>
        ) : (
          <div className="agents-grid">
            {agents.map((agent, index) => {
              const agentInfo = getAgentInfo(agent);
              const stats = agentStats[agent] || { messages: 0, lastActive: null, status: 'idle' };
              
              return (
                <div key={index} className={`agent-card ${agentInfo.color}`}>
                  <div className="agent-header">
                    <div className="agent-avatar">
                      <span className="agent-icon">{agentInfo.icon}</span>
                      <div className={`status-indicator ${stats.status}`}></div>
                    </div>
                    <div className="agent-info">
                      <h4 className="agent-name">{agent}</h4>
                      <p className="agent-desc">{agentInfo.description}</p>
                    </div>
                  </div>
                  
                  <div className="agent-stats">
                    <div className="stat-item">
                      <span className="stat-label">Messages</span>
                      <span className="stat-value">{stats.messages || 0}</span>
                    </div>
                    <div className="stat-item">
                      <span className="stat-label">Status</span>
                      <span className={`stat-badge ${stats.status}`}>
                        {stats.status || 'Ready'}
                      </span>
                    </div>
                  </div>
                  
                  <div className="agent-actions">
                    <button 
                      className="agent-btn pause"
                      onClick={() => pauseAgent(agent)}
                      title="Pause Agent"
                    >
                      ⏸️
                    </button>
                    <button 
                      className="agent-btn reset"
                      onClick={() => resetAgentState(agent)}
                      title="Reset Agent"
                    >
                      <i class="bi bi-repeat"></i>
                    </button>
                    <button 
                      className="agent-btn resume"
                      onClick={() => resumeAgent(agent)}
                      title="Resume Agent"
                    >
                      ▶️
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* System Info */}
      <div className="system-info">
        <div className="info-card">
          <h4><i class="bi bi-plug-fill"></i> Connection Status</h4>
          <div className={`status-badge large ${connectionStatus}`}>
            {connectionStatus === 'connected' ? '🟢 Connected' : '🔴 Disconnected'}
          </div>
        </div>
        
        <div className="info-card">
          <h4><i class="bi bi-bar-chart-line-fill"></i> Performance</h4>
          <div className="performance-metrics">
            <div className="metric">
              <span className="metric-label">Response Time</span>
              <span className="metric-value">~{controlState.responseDelay}ms</span>
            </div>
            <div className="metric">
              <span className="metric-label">Active Agents</span>
              <span className="metric-value">{agents.length}</span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AgentControl;
