import React, { useState, useEffect, useRef } from 'react';
import socketService from '../services/socketService';

const ChatInterface = ({ agents = [], connectionStatus = 'disconnected' }) => {
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    // Listen for socket events
    const handleMessage = (messageData) => {
      const message = {
        id: Date.now() + Math.random(),
        sender: messageData.sender || messageData.agent || 'AI Agent',
        content: messageData.message || messageData.content || messageData.text || '',
        timestamp: new Date().toISOString(),
        type: messageData.type || 'message'
      };
      
      setMessages(prev => [...prev, message]);
      setIsLoading(false);
      setIsTyping(false);
    };

    const handleTyping = () => setIsTyping(true);
    const handleStopTyping = () => setIsTyping(false);

    socketService.on('message', handleMessage);
    socketService.on('ai_response', handleMessage);
    socketService.on('typing', handleTyping);
    socketService.on('stop_typing', handleStopTyping);
    
    return () => {
      socketService.off('message', handleMessage);
      socketService.off('ai_response', handleMessage);
      socketService.off('typing', handleTyping);
      socketService.off('stop_typing', handleStopTyping);
    };
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = () => {
    if (!inputMessage.trim() || connectionStatus !== 'connected') return;

    const userMessage = {
      id: Date.now(),
      sender: 'Human',
      content: inputMessage,
      timestamp: new Date().toISOString(),
      type: 'message'
    };

    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);
    setIsTyping(true);

    // Send message via socket
    socketService.emit('user_message', {
      message: inputMessage,
      timestamp: new Date().toISOString()
    });

    setInputMessage('');
    
    // Auto-focus input after sending
    setTimeout(() => inputRef.current?.focus(), 100);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      if (e.shiftKey) {
        // Allow line break with Shift+Enter
        return;
      } else {
        e.preventDefault();
        handleSendMessage();
      }
    }
  };

  const insertTag = (tag) => {
    const newValue = inputMessage + tag + ' ';
    setInputMessage(newValue);
    inputRef.current?.focus();
  };

  const formatContent = (content) => {
    if (!content) return '';
    
    let formattedContent = content;
    
    // Format mentions with colors
    formattedContent = formattedContent.replace(/@(PO|SCRUM)/g, '<span class="mention mention-po">@$1</span>');
    formattedContent = formattedContent.replace(/@SENIOR/g, '<span class="mention mention-senior">@SENIOR</span>');
    formattedContent = formattedContent.replace(/@JUNIOR/g, '<span class="mention mention-junior">@JUNIOR</span>');
    formattedContent = formattedContent.replace(/@CEO/g, '<span class="mention mention-ceo">@CEO</span>');
    formattedContent = formattedContent.replace(/@ALL/g, '<span class="mention mention-all">@ALL</span>');
    formattedContent = formattedContent.replace(/@HUMAN/g, '<span class="mention mention-human">@HUMAN</span>');
    
    // Format code blocks
    formattedContent = formattedContent.replace(/```([^`]+)```/g, '<div class="code-block"><pre>$1</pre></div>');
    formattedContent = formattedContent.replace(/`([^`]+)`/g, '<span class="inline-code">$1</span>');
    
    // Format links
    formattedContent = formattedContent.replace(
      /(https?:\/\/[^\s]+)/g, 
      '<a href="$1" target="_blank" class="message-link">$1</a>'
    );
    
    return formattedContent;
  };

  const getAgentInfo = (sender) => {
    const agentMap = {
      'Human': { emoji: '👤', name: 'Human', color: 'user' },
      'Junior Developer': { emoji: '👨‍💻', name: 'Junior Dev', color: 'junior' },
      'Senior Developer': { emoji: '👩‍💻', name: 'Senior Dev', color: 'senior' },
      'Scrum Master/PO': { emoji: '👔', name: 'Product Owner', color: 'po' },
      'CEO': { emoji: '💼', name: 'CEO', color: 'ceo' },
      'AI Agent': { emoji: '<i class="bi bi-robot"></i>', name: 'AI Assistant', color: 'agent' }
    };
    
    return agentMap[sender] || { emoji: '<i class="bi bi-robot"></i>', name: sender, color: 'agent' };
  };

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    const minutes = Math.floor(diff / 60000);
    
    if (minutes < 1) return 'now';
    if (minutes < 60) return `${minutes}m ago`;
    if (minutes < 1440) return `${Math.floor(minutes / 60)}h ago`;
    
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <>
      {/* Chat Header */}
      <div className="chat-header">
        <div className="header-info">
          <h2 className="chat-title"><i class="bi bi-rocket-takeoff-fill"></i> AI Development Team</h2>
          <div className="chat-status">
            <div className={`status-dot ${connectionStatus}`}></div>
            <span className="status-text">
              {connectionStatus === 'connected' ? 'Connected' : 'Connecting...'}
            </span>
            <span className="agent-count">• {agents.length} agents ready</span>
          </div>
        </div>
        <div className="header-actions">
          <button className="header-btn" title="Clear Chat">
            <span>🗑️</span>
          </button>
          <button className="header-btn" title="Settings">
            <span><i class="bi bi-gear"></i></span>
          </button>
        </div>
      </div>

      {/* Messages Area */}
      <div className="messages-container">
        <div className="messages">
          {messages.length === 0 ? (
            <div className="welcome-screen">
              <div className="welcome-content">
                <div className="welcome-icon"><i class="bi bi-rocket-takeoff-fill"></i></div>
                <h3 className="welcome-title">Welcome to AI Development Team</h3>
                <p className="welcome-subtitle">
                  Your intelligent coding assistants are ready to help build amazing software
                </p>
                <div className="quick-actions">
                  <button className="quick-btn" onClick={() => insertTag('@ALL')}>
                    <span>👥</span> Ask Everyone
                  </button>
                  <button className="quick-btn" onClick={() => insertTag('@SENIOR')}>
                    <span>👩‍💻</span> Senior Review
                  </button>
                  <button className="quick-btn" onClick={() => insertTag('@JUNIOR')}>
                    <span>👨‍💻</span> Junior Task
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <>
              {messages.map((message) => {
                const agentInfo = getAgentInfo(message.sender);
                return (
                  <div key={message.id} className={`message-wrapper ${agentInfo.color}`}>
                    <div className="message">
                      <div className="message-avatar">
                        <div className={`avatar ${agentInfo.color}`}>
                          {agentInfo.emoji}
                        </div>
                        <div className="avatar-glow"></div>
                      </div>
                      <div className="message-content">
                        <div className="message-header">
                          <span className="sender-name">{agentInfo.name}</span>
                          <span className="message-time">
                            {formatTimestamp(message.timestamp)}
                          </span>
                        </div>
                        <div 
                          className="message-text" 
                          dangerouslySetInnerHTML={{ 
                            __html: formatContent(message.content) 
                          }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
              
              {/* Typing Indicator */}
              {isTyping && (
                <div className="message-wrapper agent">
                  <div className="message">
                    <div className="message-avatar">
                      <div className="avatar agent">
                        <div className="typing-indicator">
                          <span></span>
                          <span></span>
                          <span></span>
                        </div>
                      </div>
                      <div className="avatar-glow"></div>
                    </div>
                    <div className="message-content">
                      <div className="message-header">
                        <span className="sender-name">AI is thinking...</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Area */}
      <div className="input-container">
        {/* Agent Tags */}
        <div className="tag-selector">
          <div className="tag-group">
            <button className="agent-tag po" onClick={() => insertTag('@PO')}>
              <span className="tag-icon">👔</span>
              <span className="tag-label">PO</span>
            </button>
            <button className="agent-tag senior" onClick={() => insertTag('@SENIOR')}>
              <span className="tag-icon">👩‍💻</span>
              <span className="tag-label">SENIOR</span>
            </button>
            <button className="agent-tag junior" onClick={() => insertTag('@JUNIOR')}>
              <span className="tag-icon">👨‍💻</span>
              <span className="tag-label">JUNIOR</span>
            </button>
            <button className="agent-tag all" onClick={() => insertTag('@ALL')}>
              <span className="tag-icon">👥</span>
              <span className="tag-label">ALL</span>
            </button>
            <button className="agent-tag ceo" onClick={() => insertTag('@CEO')}>
              <span className="tag-icon">💼</span>
              <span className="tag-label">CEO</span>
            </button>
          </div>
        </div>
        
        {/* Message Input */}
        <div className="input-wrapper">
          <div className="input-field">
            <textarea
              ref={inputRef}
              className="message-input"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder="Ask your AI team anything... Use @SENIOR, @JUNIOR, @PO, @ALL to target specific agents"
              rows={1}
              disabled={connectionStatus !== 'connected'}
            />
            <div className="input-actions">
              <button 
                className="action-btn"
                onClick={() => setInputMessage('')}
                disabled={!inputMessage}
                title="Clear"
              >
                ✕
              </button>
            </div>
          </div>
          <button 
            className={`send-button ${inputMessage.trim() && connectionStatus === 'connected' ? 'active' : ''}`}
            onClick={handleSendMessage}
            disabled={!inputMessage.trim() || connectionStatus !== 'connected'}
          >
            <span className="send-icon"><i class="bi bi-rocket-takeoff-fill"></i></span>
            <span className="send-text">Send</span>
          </button>
        </div>
        
        {/* Status Bar */}
        <div className="input-status">
          <div className="connection-info">
            <span className={`connection-dot ${connectionStatus}`}></span>
            <span className="connection-text">
              {connectionStatus === 'connected' 
                ? `Connected • ${agents.length} agents online` 
                : 'Connecting to AI team...'}
            </span>
          </div>
          <div className="input-hint">
            Press <kbd>Enter</kbd> to send, <kbd>Shift+Enter</kbd> for new line
          </div>
        </div>
      </div>
    </>
  );
};

export default ChatInterface;
